import fs from "fs";
import path from "path";
import { google } from "googleapis";
import { createClient } from "redis";

const ADMIN_PASS = process.env.ADMIN_PASS;
const MODERATOR_PASS = process.env.MODERATOR_PASS;
const uploadsPath = path.join(process.cwd(), "uploads.json");
const folderId = process.env.GOOGLE_DRIVE_FOLDER_ID;

const oauthClient = JSON.parse(
  fs.readFileSync(path.join(process.cwd(), "oauth-client.json"), "utf8")
);
const tokenData = JSON.parse(process.env.GOOGLE_TOKEN_JSON || "{}");

const oauth2Client = new google.auth.OAuth2(
  oauthClient.web.client_id,
  oauthClient.web.client_secret,
  oauthClient.web.redirect_uris[0]
);
oauth2Client.setCredentials(tokenData);

let globalForRedis = globalThis.__redis || null;
if (!globalForRedis && process.env.REDIS_URL) {
  const client = createClient({ url: process.env.REDIS_URL });
  globalForRedis = client;
  globalThis.__redis = client;
  client.connect().catch(console.error);
}
const redis = globalForRedis;

export default async function handler(req, res) {
  const action = req.query.action;
  const isLocal = process.env.VERCEL_ENV !== "production";

  if (
    req.method === "POST" &&
    req.headers["content-type"]?.includes("application/json")
  ) {
    let body = "";
    await new Promise((resolve) => {
      req.on("data", (chunk) => (body += chunk));
      req.on("end", resolve);
    });
    try {
      req.body = JSON.parse(body);
    } catch (e) {
      return res.status(400).json({ error: "Invalid JSON" });
    }
  }

  if (action === "login" && req.method === "POST") {
    const { password } = req.body;
    if (password === ADMIN_PASS) return res.json({ success: true, role: "admin" });
    if (password === MODERATOR_PASS) return res.json({ success: true, role: "moderator" });
    return res.status(401).json({ success: false, error: "Invalid password" });
  }

  if (action === "config" && req.method === "GET") {
    try {
      if (isLocal) {
        const config = JSON.parse(fs.readFileSync(path.join(process.cwd(), "config.json"), "utf8"));
        return res.status(200).json(config);
      } else {
        const showName = await redis.get("showName");
        const startTime = await redis.get("startTime");
        const endTime = await redis.get("endTime");
        return res.status(200).json({ showName, startTime, endTime });
      }
    } catch {
      return res.status(500).json({ error: "Failed to load config" });
    }
  }

  if (action === "config" && req.method === "POST") {
    try {
      const { showName, startTime, endTime } = req.body;
      if (isLocal) {
        fs.writeFileSync(path.join(process.cwd(), "config.json"), JSON.stringify({ showName, startTime, endTime }, null, 2));
      } else {
        await redis.set("showName", showName || "");
        await redis.set("startTime", startTime || "");
        await redis.set("endTime", endTime || "");
      }
      return res.status(200).json({ success: true });
    } catch {
      return res.status(500).json({ error: "Failed to save config" });
    }
  }

  if (action === "pick-winner") {
    try {
      let allUploads = [];

      if (isLocal) {
        const fileData = fs.readFileSync(uploadsPath, "utf8");
        allUploads = JSON.parse(fileData);
      } else {
        const raw = await redis.lRange("uploads", 0, -1);
        allUploads = raw.map((entry) => JSON.parse(entry));
      }

      if (!Array.isArray(allUploads) || allUploads.length === 0) {
        return res.status(404).json({ error: "No entries found" });
      }

      const drive = google.drive({ version: "v3", auth: oauth2Client });
      const resp = await drive.files.list({
        q: `'${folderId}' in parents and trashed=false`,
        fields: "files(id)",
      });

      const liveFileIds = new Set(resp.data.files.map((f) => f.id));

      const eligibleUploads = allUploads.filter((entry) => {
        const id = entry.driveFileId || entry.fileId;
        return id && liveFileIds.has(id);
      });

      const allEntries = [];
      eligibleUploads.forEach((entry) => {
        const name = entry.name || entry.userName;
        const count = parseInt(entry.count || 1);
        if (!name) return;
        for (let i = 0; i < count; i++) allEntries.push(name);
      });

      if (allEntries.length === 0) {
        return res.status(400).json({ error: "No valid entries with active files" });
      }

      const winner = allEntries[Math.floor(Math.random() * allEntries.length)];

      if (!isLocal) {
        await redis.set("raffle_winner", JSON.stringify({ name: winner, timestamp: Date.now() }));
      }

      return res.json({ winner });
    } catch (err) {
      console.error("🔥 pick-winner failed:", err);
      return res.status(500).json({ error: "Failed to pick winner" });
    }
  }

  if (action === "delete-file" && req.method === "POST") {
    const { fileId } = req.body;
    if (!fileId) return res.status(400).json({ error: "Missing file ID" });

    try {
      const drive = google.drive({ version: "v3", auth: oauth2Client });
      await drive.files.delete({ fileId });
      return res.json({ success: true });
    } catch {
      return res.status(500).json({ error: "Failed to delete file" });
    }
  }

  if (action === "dump-uploads") {
    try {
      if (!isLocal) {
        const raw = await redis.lRange("uploads", 0, -1);
        const parsed = raw.map(JSON.parse);
        return res.json(parsed);
      } else {
        const fileData = fs.readFileSync(uploadsPath, "utf8");
        return res.json(JSON.parse(fileData));
      }
    } catch {
      return res.status(500).json({ error: "Failed to dump uploads" });
    }
  }

  if (action === "clear-all" && req.method === "POST") {
    const { role } = req.body;
    if (role !== "admin") return res.status(403).json({ error: "Unauthorized" });

    try {
      if (!isLocal) {
        await redis.del("uploads");
      } else {
        fs.writeFileSync(uploadsPath, "[]");
      }

      const drive = google.drive({ version: "v3", auth: oauth2Client });
      const resp = await drive.files.list({
        q: `'${folderId}' in parents and trashed=false`,
        fields: "files(id)",
      });

      await Promise.all(resp.data.files.map((file) => drive.files.delete({ fileId: file.id })));

      return res.json({ success: true });
    } catch (err) {
      console.error("🔥 clear-all error:", err);
      return res.status(500).json({ error: "Failed to clear all data" });
    }
  }

  if (action === "winner" && req.method === "GET") {
    try {
      if (isLocal) return res.json({ winner: null });

      const redisClient = createClient({ url: process.env.REDIS_URL });
      await redisClient.connect();
      const winnerData = await redisClient.getDel("raffle_winner");
      await redisClient.disconnect();

      if (!winnerData) return res.json({ winner: null });

      return res.json({ winner: JSON.parse(winnerData) });
    } catch (err) {
      console.error("🔥 winner fetch error:", err);
      return res.status(500).json({ error: "Failed to fetch winner" });
    }
  }

  if (action === "upvote" && req.method === "POST") {
    try {
      const { fileId } = req.body;
      if (!fileId) return res.status(400).json({ error: "Missing fileId" });

      const key = `votes:${fileId}`;
      const newCount = await redis.incr(key);
      return res.json({ success: true, votes: newCount });
    } catch (err) {
      console.error("🔥 upvote error:", err);
      return res.status(500).json({ error: "Failed to upvote" });
    }
  }

  if (action === "reset-votes" && req.method === "POST") {
    try {
      const { role } = req.body;
      if (role !== "admin") return res.status(403).json({ error: "Unauthorized" });

      const keys = await redis.keys("votes:*");
      if (keys.length > 0) await redis.del(keys);

      await redis.set("resetVotesTimestamp", Date.now().toString());

      return res.json({ success: true });
    } catch (err) {
      console.error("🔥 reset-votes error:", err);
      return res.status(500).json({ error: "Failed to reset votes" });
    }
  }

  if (req.method === "GET" && action === "list-drive-files") {
    try {
      const drive = google.drive({ version: "v3", auth: oauth2Client });

      const driveRes = await drive.files.list({
        q: `'${process.env.GOOGLE_DRIVE_FOLDER_ID}' in parents and trashed = false`,
        fields: "files(id, name, mimeType, createdTime)",
        orderBy: "createdTime desc",
        pageSize: 100,
      });

      const driveFiles = driveRes.data.files || [];
      const uploads = await redis.lRange("uploads", 0, -1);
      const metadataMap = new Map();

      for (const entry of uploads) {
        try {
          const upload = JSON.parse(entry);
          const key = upload.id || upload.fileName;
          metadataMap.set(key, upload);
        } catch {
          continue;
        }
      }

      const enrichedFiles = driveFiles.map((file) => {
        const key = file.id || file.name;
        const metadata = metadataMap.get(key);

        return {
          id: file.id,
          fileName: file.name,
          mimeType: file.mimeType,
          createdTime: file.createdTime,
          fileUrl: `https://drive.google.com/uc?id=${file.id}`,
          userName: metadata?.userName || "Anonymous",
          votes: metadata?.votes || 0,
        };
      });

      return res.status(200).json(enrichedFiles);
    } catch (err) {
      console.error("❌ Failed to list drive files:", err);
      return res.status(500).json({ error: "Failed to list drive files" });
    }
  }

  if (action === "check-reset" && req.method === "GET") {
    try {
      const resetTimestamp = await redis.get("resetVotesTimestamp");
      return res.json({ resetTimestamp });
    } catch (err) {
      console.error("🔥 check-reset error:", err);
      return res.status(500).json({ error: "Failed to check reset timestamp" });
    }
  }

  if (action === "social-counts" && req.method === "GET") {
    return res.status(200).json({
      facebook: { followers: 1234 },
      instagram: { followers: 5678 },
    });
  }

  if (action === "followers" && req.method === "GET") {
    try {
      const token = process.env.FB_PAGE_TOKEN;
      const fbPageId = process.env.FB_PAGE_ID;
      const igAccountId = process.env.IG_ACCOUNT_ID;

      const fbRes = await fetch(
        `https://graph.facebook.com/v19.0/${fbPageId}?fields=fan_count&access_token=${token}`
      );
      const fbJson = await fbRes.json();

      const igRes = await fetch(
        `https://graph.facebook.com/v19.0/${igAccountId}?fields=followers_count&access_token=${token}`
      );
      const igJson = await igRes.json();

      return res.json({
        facebook: fbJson.fan_count || 0,
        instagram: igJson.followers_count || 0,
      });
    } catch (err) {
      console.error("🔥 followers fetch error:", err);
      return res.status(500).json({ error: "Failed to fetch follower counts" });
    }
  }

  if (req.method === "POST" && action === "save-upload") {
    try {
      const { fileId, fileName, mimeType, userName } = req.body;
      if (!fileName || !mimeType || !userName) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const uploadsKey = "uploads";
      const id = fileId || fileName;
      const fileUrl = `https://drive.google.com/uc?id=${id}`;

      const upload = {
        id,
        fileName,
        mimeType,
        userName,
        fileUrl,
        createdTime: new Date().toISOString(),
        votes: 0,
      };

      const existing = await redis.lRange(uploadsKey, 0, -1);
      const alreadyExists = existing.some((item) => {
        try {
          return JSON.parse(item).id === id;
        } catch {
          return false;
        }
      });

      if (!alreadyExists) {
        await redis.rPush(uploadsKey, JSON.stringify(upload));
      }

      return res.status(200).json({ success: true, upload });
    } catch (err) {
      console.error("❌ Failed to save upload metadata:", err);
      return res.status(500).json({ error: "Failed to save metadata" });
    }
  }

  res.status(400).json({ error: "Invalid action" });
}
