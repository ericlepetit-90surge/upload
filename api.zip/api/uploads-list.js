// /api/upload-file.js
import { google } from 'googleapis';
import { IncomingForm } from 'formidable';
import fs from 'fs';
import path from 'path';

export const config = {
  api: {
    bodyParser: false,
  },
};

const oauthClientPath = path.join(process.cwd(), 'oauth-client.json');
const credentials = JSON.parse(fs.readFileSync(oauthClientPath, 'utf8'));
const tokenData = JSON.parse(process.env.GOOGLE_TOKEN_JSON);

const { client_id, client_secret, redirect_uris } = credentials.web;
const oauth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
oauth2Client.setCredentials(tokenData);

function sanitize(str) {
  return String(str || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .substring(0, 80);
}

export default function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const form = new IncomingForm({ keepExtensions: true });

  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error('❌ Form parse error:', err);
      return res.status(500).json({ error: 'Form error' });
    }

    const { userName } = fields;
    const file = files.file;

    if (!file || !userName) {
      return res.status(400).json({ error: 'Missing file or name' });
    }

    const drive = google.drive({ version: 'v3', auth: oauth2Client });

    try {
      const fileMetadata = {
        name: `${sanitize(userName)}_${Date.now()}_${file.originalFilename}`,
        parents: [process.env.GOOGLE_DRIVE_FOLDER_ID],
      };

      const media = {
        mimeType: file.mimetype,
        body: fs.createReadStream(file.filepath),
      };

      const uploadRes = await drive.files.create({
        requestBody: fileMetadata,
        media,
        fields: 'id',
      });

      console.log('✅ Uploaded to Drive:', uploadRes.data.id);
      res.status(200).json({ success: true, fileId: uploadRes.data.id });
    } catch (uploadErr) {
      console.error('❌ Upload failed:', uploadErr);
      res.status(500).json({ error: 'Upload to Drive failed' });
    }
  });
}
